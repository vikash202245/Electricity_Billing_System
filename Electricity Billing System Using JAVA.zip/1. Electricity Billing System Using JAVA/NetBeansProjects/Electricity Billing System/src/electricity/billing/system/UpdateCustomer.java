package electricity.billing.system;

import javax.swing.*;

public class UpdateCustomer extends JFrame{
    UpdateCustomer()
    {
        super("Update Customer");
        setSize(800,400);
        setLocation(350,150);
    }
    public static void main(String[]args)
    {
        new UpdateCustomer();
    }
}
